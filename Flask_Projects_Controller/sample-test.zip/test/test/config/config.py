from os import environ


#https://flask.palletsprojects.com/en/3.0.x/config/#configuration-basics

class Config():

    ENV = environ.get("TEST_API_ENV", "production")

    DEBUG = bool(int(environ.get("TEST_API_DEBUG", "0")))

    TESTING = DEBUG

    SECRET_KEY = environ.get("TEST_API_SECRET_KEY", "secretkey")

    JSONIFY_PRETTYPRINT_REGULAR = bool(
        int(environ.get("TEST_API_JSON_PRETTYPRINT", "0"))
    )
