#!bin/python3
from flask import Flask,Blueprint
from flask_restful import Api

from .config import Config

bp1=Blueprint("app_bp1","__name__",url_prefix="/bp1")

apiv1 = Api(bp1)


def create_app():
    app = Flask(__name__)
    print ("hellllllllo")    
    print (__name__)    
    print(app.config)    
    print(Config.DEBUG)
    print(Config.ENV)
    print(Config.JSONIFY_PRETTYPRINT_REGULAR)
    print(Config.SECRET_KEY)
    print(Config.TESTING)
    
    app.config.from_object(Config)
    app.register_blueprint(bp1)
    print(app.config)
    return app

#app = Flask (__name__)
#@app.route("/")
#def root(): 
#      return "hi..."

#@app.route("/sub1/")
#def sub1(): 
#      return "hi..SUB1."
