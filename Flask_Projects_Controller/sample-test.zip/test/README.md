# dotaco

dotaco is a doker container-based task controller and runner (to run user tasks in Docker and Kubernetes).

Simple API with Flask web framework that I use to perform some DevOps-related neaded topics.

Copyright &copy; 2023 Mohammad Nasseri <mo.nasseri@gmail.com>
